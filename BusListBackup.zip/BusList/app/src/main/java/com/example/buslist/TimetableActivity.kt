package com.example.buslist

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class TimetableActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timetable)

        // Customize the behavior and data display for your timetable activity
    }
}
