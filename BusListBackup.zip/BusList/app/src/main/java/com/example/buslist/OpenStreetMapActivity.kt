package com.example.buslist

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONException
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.Marker
import java.io.IOException
import java.io.InputStream

class OpenStreetMapActivity : AppCompatActivity() {

    private lateinit var mapView: MapView
    private lateinit var waypoints: List<GeoPoint>
    private lateinit var descriptions: List<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_osm)

        // Initialize OSMDroid configuration
        Configuration.getInstance().load(applicationContext, getPreferences(MODE_PRIVATE))

        mapView = findViewById(R.id.mapView)
        mapView.setUseDataConnection(true) // Set to false for offline mode
        mapView.setTileSource(TileSourceFactory.DEFAULT_TILE_SOURCE) // Or TileSourceFactory.MAPNIK
        mapView.zoomController.setVisibility(CustomZoomButtonsController.Visibility.SHOW_AND_FADEOUT)
        mapView.setMultiTouchControls(true)


        val jsonFileName = "selita.json"
        val json: String? = loadJSONFromAsset(jsonFileName)

        if (json != null) {
            val (parsedWaypoints, parsedDescriptions) = parseRouteJSON(json)
            waypoints = parsedWaypoints
            descriptions = parsedDescriptions

            val routePolyline = Polyline(mapView)
            waypoints.forEach { waypoint ->
                routePolyline.addPoint(waypoint)
            }
            mapView.overlays.add(routePolyline)

            addMarkersToMap(mapView, waypoints, descriptions)

            if (waypoints.isNotEmpty()) {
                val firstWaypoint = waypoints.first()
                mapView.controller.setCenter(firstWaypoint)
                mapView.controller.setZoom(16.0)
                mapView.tileProvider.clearTileCache()
                mapView.invalidate()
            }
        }
    }

    private fun parseRouteJSON(json: String): Pair<List<GeoPoint>, List<String>> {
        val parsedWaypoints = mutableListOf<GeoPoint>()
        val parsedDescriptions = mutableListOf<String>()

        try {
            val jsonArray = JSONArray(json)
            for (i in 0 until jsonArray.length()) {
                val jsonArrayItem = jsonArray.getJSONArray(i)
                val lat = jsonArrayItem.getDouble(0)
                val lon = jsonArrayItem.getDouble(1)
                parsedWaypoints.add(GeoPoint(lat, lon))

                if (jsonArrayItem.length() >= 3) {
                    val description = jsonArrayItem.getString(2)
                    parsedDescriptions.add(description)
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        Log.d("ParsingDebug", "Parsed Waypoints: $parsedWaypoints")
        Log.d("ParsingDebug", "Parsed Descriptions: $parsedDescriptions")

        return Pair(parsedWaypoints, parsedDescriptions)
    }



    private fun addMarkersToMap(mapView: MapView, waypoints: List<GeoPoint>, descriptions: List<String>) {
        for (i in waypoints.indices) {
            val waypoint = waypoints[i]
            val description = if (i < descriptions.size) descriptions[i] else ""

            val marker = Marker(mapView)
            marker.position = waypoint
            marker.title = description
            mapView.overlays.add(marker)
        }
    }

    private fun loadJSONFromAsset(fileName: String): String? {
        var json: String? = null
        try {
            val inputStream: InputStream = assets.open(fileName)
            val size: Int = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            json = String(buffer, Charsets.UTF_8)
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return json
    }
}
